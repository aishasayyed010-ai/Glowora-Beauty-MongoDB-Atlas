# Glowora Beauty — Full Stack Store

Glowora Beauty is a React + Express + MongoDB Atlas e-commerce project with a separate admin dashboard.

The code is intentionally kept straightforward: small route sections, descriptive names, normal async/await and comments only where they help explain business logic.

## What is included

- React/Vite storefront
- Customer signup and login
- Password hashing with bcrypt
- JWT authentication
- Product catalogue stored in MongoDB
- Cart and checkout
- Orders stored in MongoDB
- Stock is reduced atomically when an order is created
- Customer order history
- Separate admin login and dashboard
- Revenue, product cost, gross profit and inventory value
- Remaining units and low-stock count
- Customer and order counts
- Sales by category
- Add/edit/archive products
- Update order status

## MongoDB Atlas setup

You need a MongoDB Atlas connection string. The project cannot safely contain your Atlas username/password inside the ZIP, so the connection string belongs in `server/.env` on your computer.

### 1. Create the Atlas database

In MongoDB Atlas:

1. Create a cluster.
2. Create a database user.
3. In Network Access, add your current IP address for development. Do not use `0.0.0.0/0` unless you understand the security implications.
4. Choose **Connect → Drivers → Node.js** and copy the connection string.

It will look similar to:

```text
mongodb+srv://USERNAME:PASSWORD@cluster0.xxxxx.mongodb.net/glowora_beauty?retryWrites=true&w=majority
```

If your password contains characters such as `@`, `#`, `/` or `:`, URL-encode the password before putting it in the URI.

### 2. Create the backend environment file

From the project root:

```powershell
cd server
copy .env.example .env
```

Open `server/.env` and replace `MONGODB_URI` with your real Atlas connection string.

Also replace `JWT_SECRET` with a long random secret of at least 32 characters.

### 3. Install and start the backend

```powershell
cd server
npm install
npm run dev
```

A successful startup should show:

```text
MongoDB connected.
Glowora API running at http://localhost:5000
```

Check:

```text
http://localhost:5000/api/health
```

The response should contain:

```json
{
  "ok": true,
  "database": "connected"
}
```

The first startup automatically creates the admin account and starter products if they do not already exist.

## Frontend

Open a second VS Code terminal from the project root:

```powershell
npm install
copy .env.example .env
npm run dev
```

Open the URL Vite prints, normally:

```text
http://localhost:5173
```

The frontend calls:

```text
http://localhost:5000/api
```

You can change this in the root `.env` with `VITE_API_URL` if your backend is hosted elsewhere.

## Admin dashboard

Open:

```text
http://localhost:5173/admin/login
```

Default development admin:

```text
Email: admin@glowora.com
Password: GloworaAdmin@2026!
```

Change `ADMIN_EMAIL` and `ADMIN_PASSWORD` in `server/.env` before production.

## Important Atlas note

You do **not** need to manually create the `users`, `products` or `orders` collections. Mongoose creates them when the application first writes data.

MongoDB Atlas is the actual database. Your React frontend never connects directly to Atlas; it talks to the Express API, and the Express API talks to Atlas. This keeps the database credentials out of the browser.

## Troubleshooting

### MongoServerError: bad auth

Your Atlas database username/password is incorrect. Re-copy the connection string from Atlas and make sure special characters in the password are URL-encoded.

### IP is not allowed

Open Atlas → Network Access and add your current IP address.

### JWT_SECRET error

Make sure `JWT_SECRET` in `server/.env` is at least 32 characters.

### Port 5000 is already in use

Change `PORT=5000` in `server/.env` and update the frontend `VITE_API_URL` accordingly.

## Security before deployment

- Use a new strong admin password.
- Use a new random JWT secret.
- Restrict Atlas Network Access to your server's IP in production.
- Never commit `.env` to GitHub.
- Add a real payment provider before accepting real payments.
- Add HTTPS when deployed.
