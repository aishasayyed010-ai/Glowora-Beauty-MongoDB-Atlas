require("dotenv").config();

const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const app = express();
const PORT = Number(process.env.PORT) || 5000;

app.use(
  cors({
    origin: process.env.CLIENT_URL || "http://localhost:5173",
  })
);
app.use(express.json());

// -----------------------------
// Database models
// -----------------------------

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 80 },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    password: { type: String, required: true, minlength: 6 },
    role: {
      type: String,
      enum: ["customer", "admin"],
      default: "customer",
    },
  },
  { timestamps: true }
);

const productSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    category: { type: String, required: true, trim: true },
    price: { type: Number, required: true, min: 0 },
    cost: { type: Number, required: true, min: 0, default: 0 },
    stock: { type: Number, required: true, min: 0, default: 0 },
    image: { type: String, default: "" },
    active: { type: Boolean, default: true },
  },
  { timestamps: true }
);

const orderSchema = new mongoose.Schema(
  {
    orderNumber: { type: String, unique: true, required: true },
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    customer: {
      name: String,
      phone: String,
      address: String,
      pincode: String,
      location: String,
      landmark: String,
    },
    items: [
      {
        productId: mongoose.Schema.Types.ObjectId,
        name: String,
        price: Number,
        cost: Number,
        quantity: Number,
        image: String,
      },
    ],
    pricing: {
      subtotal: Number,
      shipping: Number,
      gst: Number,
      total: Number,
    },
    status: {
      type: String,
      enum: ["Order Placed", "Processing", "Shipped", "Delivered", "Cancelled"],
      default: "Order Placed",
    },
  },
  { timestamps: true }
);

const User = mongoose.model("User", userSchema);
const Product = mongoose.model("Product", productSchema);
const Order = mongoose.model("Order", orderSchema);

// -----------------------------
// Small helpers
// -----------------------------

function createToken(user) {
  return jwt.sign(
    {
      id: user._id,
      role: user.role,
      name: user.name,
      email: user.email,
    },
    process.env.JWT_SECRET,
    { expiresIn: "7d" }
  );
}

function auth(req, res, next) {
  try {
    const header = req.headers.authorization || "";

    if (!header.startsWith("Bearer ")) {
      return res.status(401).json({ message: "Authentication required." });
    }

    req.user = jwt.verify(header.slice(7), process.env.JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ message: "Invalid or expired token." });
  }
}

function adminOnly(req, res, next) {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ message: "Admin access required." });
  }

  next();
}

function publicUser(user) {
  return {
    id: user._id,
    name: user.name,
    email: user.email,
    role: user.role,
  };
}

// -----------------------------
// Health check
// -----------------------------

app.get("/api/health", (req, res) => {
  res.json({
    ok: true,
    service: "Glowora Beauty API",
    database: mongoose.connection.readyState === 1 ? "connected" : "disconnected",
  });
});

// -----------------------------
// Authentication
// -----------------------------

app.post("/api/auth/signup", async (req, res) => {
  try {
    const name = String(req.body.name || "").trim();
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");

    if (!name || !email || password.length < 6) {
      return res.status(400).json({
        message: "Name, email and a password of at least 6 characters are required.",
      });
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(409).json({ message: "An account with this email already exists." });
    }

    const hashedPassword = await bcrypt.hash(password, 12);
    const user = await User.create({ name, email, password: hashedPassword });

    res.status(201).json({
      token: createToken(user),
      user: publicUser(user),
    });
  } catch (error) {
    console.error("Signup error:", error.message);
    res.status(500).json({ message: "Signup failed. Please try again." });
  }
});

app.post("/api/auth/login", async (req, res) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");

    const user = await User.findOne({ email });
    const passwordMatches = user && (await bcrypt.compare(password, user.password));

    if (!passwordMatches) {
      return res.status(401).json({ message: "Invalid email or password." });
    }

    res.json({
      token: createToken(user),
      user: publicUser(user),
    });
  } catch (error) {
    console.error("Login error:", error.message);
    res.status(500).json({ message: "Login failed. Please try again." });
  }
});

app.get("/api/auth/me", auth, async (req, res) => {
  const user = await User.findById(req.user.id).select("-password");

  if (!user) {
    return res.status(404).json({ message: "User not found." });
  }

  res.json({ user });
});

// -----------------------------
// Products
// -----------------------------

app.get("/api/products", async (req, res) => {
  try {
    const filter = { active: true };

    if (req.query.category) {
      filter.category = req.query.category;
    }

    if (req.query.search) {
      filter.name = { $regex: String(req.query.search), $options: "i" };
    }

    const products = await Product.find(filter).sort({ createdAt: -1 });
    res.json(products);
  } catch (error) {
    console.error("Products error:", error.message);
    res.status(500).json({ message: "Unable to load products." });
  }
});

app.get("/api/products/admin", auth, adminOnly, async (req, res) => {
  const products = await Product.find().sort({ createdAt: -1 });
  res.json(products);
});

app.post("/api/products", auth, adminOnly, async (req, res) => {
  try {
    const product = await Product.create({
      name: req.body.name,
      category: req.body.category,
      price: Number(req.body.price),
      cost: Number(req.body.cost),
      stock: Number(req.body.stock),
      image: req.body.image || "",
    });

    res.status(201).json(product);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

app.put("/api/products/:id", auth, adminOnly, async (req, res) => {
  try {
    const product = await Product.findByIdAndUpdate(
      req.params.id,
      {
        name: req.body.name,
        category: req.body.category,
        price: Number(req.body.price),
        cost: Number(req.body.cost),
        stock: Number(req.body.stock),
        image: req.body.image || "",
        active: req.body.active !== false,
      },
      { new: true, runValidators: true }
    );

    if (!product) {
      return res.status(404).json({ message: "Product not found." });
    }

    res.json(product);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

app.delete("/api/products/:id", auth, adminOnly, async (req, res) => {
  const product = await Product.findByIdAndUpdate(
    req.params.id,
    { active: false },
    { new: true }
  );

  if (!product) {
    return res.status(404).json({ message: "Product not found." });
  }

  res.json({ message: "Product archived." });
});

// -----------------------------
// Orders
// -----------------------------

app.post("/api/orders", auth, async (req, res) => {
  const session = await mongoose.startSession();

  try {
    const { customer, items } = req.body;

    if (
      !customer?.name ||
      !customer?.phone ||
      !customer?.address ||
      !customer?.pincode ||
      !Array.isArray(items) ||
      items.length === 0
    ) {
      return res.status(400).json({
        message: "Complete delivery details and cart items are required.",
      });
    }

    session.startTransaction();

    const productIds = items.map((item) => item.productId || item.id);
    const products = await Product.find({
      _id: { $in: productIds },
      active: true,
    }).session(session);

    const productMap = new Map(products.map((product) => [String(product._id), product]));
    const normalizedItems = [];
    let subtotal = 0;
    let productCost = 0;

    for (const item of items) {
      const product = productMap.get(String(item.productId || item.id));
      const quantity = Number(item.quantity);

      if (!product || !Number.isInteger(quantity) || quantity < 1) {
        throw new Error("One or more products in your cart are invalid.");
      }

      // The stock check happens again inside the transaction so two customers
      // cannot safely purchase the same final unit at the same time.
      const updatedProduct = await Product.findOneAndUpdate(
        { _id: product._id, active: true, stock: { $gte: quantity } },
        { $inc: { stock: -quantity } },
        { new: true, session }
      );

      if (!updatedProduct) {
        throw new Error(`Only ${product.stock} units of ${product.name} are available.`);
      }

      subtotal += product.price * quantity;
      productCost += product.cost * quantity;

      normalizedItems.push({
        productId: product._id,
        name: product.name,
        price: product.price,
        cost: product.cost,
        quantity,
        image: product.image,
      });
    }

    const shipping = subtotal >= 999 ? 0 : 49;
    const gst = Number((subtotal * 0.05).toFixed(2));
    const total = Number((subtotal + shipping + gst).toFixed(2));

    const [order] = await Order.create(
      [
        {
          orderNumber: `ORD-${Date.now().toString().slice(-8)}`,
          userId: req.user.id,
          customer,
          items: normalizedItems,
          pricing: { subtotal, shipping, gst, total },
        },
      ],
      { session }
    );

    await session.commitTransaction();

    res.status(201).json({
      order,
      // This is product gross profit. It intentionally excludes payment,
      // delivery and tax expenses because those costs are not stored yet.
      profit: Number((subtotal - productCost).toFixed(2)),
    });
  } catch (error) {
    await session.abortTransaction().catch(() => {});
    res.status(400).json({ message: error.message || "Could not place order." });
  } finally {
    await session.endSession();
  }
});

app.get("/api/orders/my", auth, async (req, res) => {
  const orders = await Order.find({ userId: req.user.id }).sort({ createdAt: -1 });
  res.json(orders);
});

app.get("/api/orders", auth, adminOnly, async (req, res) => {
  const orders = await Order.find()
    .populate("userId", "name email")
    .sort({ createdAt: -1 });

  res.json(orders);
});

app.patch("/api/orders/:id/status", auth, adminOnly, async (req, res) => {
  const allowedStatuses = [
    "Order Placed",
    "Processing",
    "Shipped",
    "Delivered",
    "Cancelled",
  ];

  if (!allowedStatuses.includes(req.body.status)) {
    return res.status(400).json({ message: "Invalid order status." });
  }

  const order = await Order.findByIdAndUpdate(
    req.params.id,
    { status: req.body.status },
    { new: true }
  );

  if (!order) {
    return res.status(404).json({ message: "Order not found." });
  }

  res.json(order);
});

// -----------------------------
// Admin dashboard
// -----------------------------

app.get("/api/admin/dashboard", auth, adminOnly, async (req, res) => {
  const [products, orders, customers] = await Promise.all([
    Product.find(),
    Order.find(),
    User.countDocuments({ role: "customer" }),
  ]);

  const validOrders = orders.filter((order) => order.status !== "Cancelled");

  let sales = 0;
  let productCost = 0;

  for (const order of validOrders) {
    sales += order.pricing.subtotal || 0;

    for (const item of order.items) {
      productCost += (item.cost || 0) * (item.quantity || 0);
    }
  }

  const profit = sales - productCost;
  const stockValue = products.reduce((sum, product) => sum + product.cost * product.stock, 0);
  const units = products.reduce((sum, product) => sum + product.stock, 0);
  const lowStock = products.filter((product) => product.stock <= 10 && product.active).length;

  const salesByCategory = {};

  for (const order of validOrders) {
    for (const item of order.items) {
      const product = products.find(
        (candidate) => String(candidate._id) === String(item.productId)
      );
      const category = product?.category || "Other";
      salesByCategory[category] =
        (salesByCategory[category] || 0) + item.price * item.quantity;
    }
  }

  res.json({
    stats: {
      revenue: Number(sales.toFixed(2)),
      cost: Number(productCost.toFixed(2)),
      profit: Number(profit.toFixed(2)),
      stockValue: Number(stockValue.toFixed(2)),
      units,
      lowStock,
      orders: orders.length,
      customers,
    },
    salesByCategory,
    recentOrders: orders.slice(0, 8),
  });
});

// -----------------------------
// Startup
// -----------------------------

async function seedDatabase() {
  const adminEmail = (process.env.ADMIN_EMAIL || "admin@glowora.com").trim().toLowerCase();
  const adminPassword = process.env.ADMIN_PASSWORD || "GloworaAdmin@2026!";

  const existingAdmin = await User.findOne({ email: adminEmail });

  if (!existingAdmin) {
    await User.create({
      name: "Glowora Admin",
      email: adminEmail,
      password: await bcrypt.hash(adminPassword, 12),
      role: "admin",
    });
    console.log(`Admin account created: ${adminEmail}`);
  }

  if (await Product.countDocuments() === 0) {
    await Product.insertMany([
      {
        name: "Rose Glow Face Serum",
        category: "Skincare",
        price: 599,
        stock: 250,
        cost: 329,
        image: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=600&q=80",
      },
      {
        name: "Hydra Dew Moisturizer",
        category: "Skincare",
        price: 449,
        stock: 180,
        cost: 247,
        image: "https://images.unsplash.com/photo-1556229010-6c3f2c9ca5f8?auto=format&fit=crop&w=600&q=80",
      },
      {
        name: "Velvet Matte Lipstick",
        category: "Makeup",
        price: 399,
        stock: 300,
        cost: 219,
        image: "https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&w=600&q=80",
      },
      {
        name: "Soft Focus Foundation",
        category: "Makeup",
        price: 799,
        stock: 150,
        cost: 439,
        image: "https://images.unsplash.com/photo-1631730486572-226d1f595b68?auto=format&fit=crop&w=600&q=80",
      },
      {
        name: "Peach Glow Blush",
        category: "Makeup",
        price: 349,
        stock: 220,
        cost: 192,
        image: "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=600&q=80",
      },
      {
        name: "Silky Hair Repair Mask",
        category: "Haircare",
        price: 549,
        stock: 140,
        cost: 302,
        image: "https://images.unsplash.com/photo-1522338242992-e1a54906a8da?auto=format&fit=crop&w=600&q=80",
      },
      {
        name: "Everyday SPF 50",
        category: "Skincare",
        price: 499,
        stock: 200,
        cost: 274,
        image: "https://images.unsplash.com/photo-1556228578-8c89e6adf883?auto=format&fit=crop&w=600&q=80",
      },
      {
        name: "Vanilla Cloud Body Mist",
        category: "Body Care",
        price: 699,
        stock: 120,
        cost: 384,
        image: "https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&w=600&q=80",
      },
    ]);

    console.log("Starter products added.");
  }
}

async function startServer() {
  if (!process.env.MONGODB_URI) {
    throw new Error("MONGODB_URI is missing. Add your MongoDB Atlas connection string to server/.env.");
  }

  if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
    throw new Error("JWT_SECRET must be at least 32 characters long.");
  }

  await mongoose.connect(process.env.MONGODB_URI);
  console.log("MongoDB connected.");

  await seedDatabase();

  app.listen(PORT, () => {
    console.log(`Glowora API running at http://localhost:${PORT}`);
  });
}

startServer().catch((error) => {
  console.error("Server startup failed:", error.message);
  process.exit(1);
});
