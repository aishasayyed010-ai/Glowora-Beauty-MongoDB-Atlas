import {useState} from "react";
import {useNavigate} from "react-router-dom";
import api from "../services/api";

export default function AdminLogin(){
 const nav=useNavigate(),[email,setEmail]=useState("admin@glowora.com"),[password,setPassword]=useState("GloworaAdmin@2026!"),[error,setError]=useState(""),[loading,setLoading]=useState(false);
 const submit=async e=>{e.preventDefault();setLoading(true);setError("");try{const r=await api.post("/auth/login",{email,password});if(r.data.user.role!=="admin")throw new Error("Not an admin account");localStorage.setItem("glowora-token",r.data.token);localStorage.setItem("glowora-current-user",JSON.stringify(r.data.user));nav("/admin");}catch(e){setError(e.response?.data?.message||e.message||"Admin login failed.");}finally{setLoading(false)}};
 return <main className="admin-auth"><form onSubmit={submit} className="admin-login-card"><p className="section-label">GLOWORA BEAUTY</p><h1>Admin Portal</h1><p>Manage products, stock, orders and profitability.</p><label>Email</label><input value={email} onChange={e=>setEmail(e.target.value)}/><label>Password</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)}/>{error&&<p className="auth-error">{error}</p>}<button>{loading?"Signing in...":"Sign in as Admin"}</button><small>Use the seeded admin credentials shown in the project README.</small></form></main>;
}
