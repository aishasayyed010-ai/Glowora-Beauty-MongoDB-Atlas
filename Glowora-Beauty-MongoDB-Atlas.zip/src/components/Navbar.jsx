import { Link } from "react-router-dom";
import {
    FiSearch,
    FiShoppingBag,
    FiUser,
} from "react-icons/fi";

function Navbar() {
    return (
        <nav className="navbar">

            {/* LOGO */}

            <Link to="/" className="logo">
                Glowora Beauty
            </Link>


            {/* NAVIGATION LINKS */}

            <div className="nav-links">

                <Link to="/">
                    Home
                </Link>

                <Link to="/products">
                    Products
                </Link>

                <Link to="/about">
                    About Us
                </Link>

                <Link to="/contact">
                    Contact
                </Link>

            </div>


            {/* NAVIGATION ICONS */}

            <div className="nav-icons">

                {/* SEARCH */}

                <Link
                    to="/products"
                    aria-label="Search products"
                >
                    <FiSearch />
                </Link>


                {/* PROFILE / LOGIN */}

                <Link
                    to="/profile"
                    aria-label="My account"
                >
                    <FiUser />
                </Link>


                {/* CART */}

                <Link
                    to="/cart"
                    aria-label="Shopping cart"
                >
                    <FiShoppingBag />
                </Link>

            </div>

        </nav>
    );
}

export default Navbar;