import { FiShoppingBag } from "react-icons/fi";
import { Link } from "react-router-dom";

function ProductCard({ product, onAddToCart }) {
  return (
    <div className="product-card">

      {/* PRODUCT IMAGE */}
      <Link to={`/products/${product.id}`}>
        <div className="product-image">
          <img
            src={product.image}
            alt={product.name}
          />
        </div>
      </Link>

      <div className="product-info">

        <p className="product-category">
          {product.category}
        </p>

        {/* PRODUCT NAME */}
        <Link
          to={`/products/${product.id}`}
          className="product-name-link"
        >
          <h3>{product.name}</h3>
        </Link>

        <p className="product-price">
          ₹{product.price.toLocaleString("en-IN")}
        </p>

        {/* ADD TO CART */}
        <button
          className="add-cart-btn"
          onClick={() => onAddToCart(product)}
        >
          <FiShoppingBag />
          Add to Cart
        </button>

      </div>

    </div>
  );
}

export default ProductCard;