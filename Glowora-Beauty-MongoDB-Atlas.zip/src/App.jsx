import {BrowserRouter,Routes,Route,useLocation} from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home"; import Products from "./pages/Products"; import Cart from "./pages/Cart"; import Checkout from "./pages/Checkout";
import About from "./pages/About"; import Profile from "./pages/Profile"; import Contact from "./pages/Contact"; import Login from "./pages/Login"; import OrderSuccess from "./pages/OrderSuccess"; import ProductDetails from "./pages/ProductDetails";
import AdminLogin from "./admin/AdminLogin"; import AdminDashboard from "./admin/AdminDashboard";

function Layout(){
 const location=useLocation(),isAdmin=location.pathname.startsWith("/admin");
 return <>{!isAdmin&&<Navbar/>}<Routes>
  <Route path="/" element={<Home/>}/><Route path="/products" element={<Products/>}/><Route path="/products/:id" element={<ProductDetails/>}/>
  <Route path="/cart" element={<Cart/>}/><Route path="/checkout" element={<Checkout/>}/><Route path="/order-success" element={<OrderSuccess/>}/>
  <Route path="/about" element={<About/>}/><Route path="/profile" element={<Profile/>}/><Route path="/contact" element={<Contact/>}/><Route path="/login" element={<Login/>}/>
  <Route path="/admin/login" element={<AdminLogin/>}/><Route path="/admin" element={<AdminDashboard/>}/>
 </Routes></>;
}
export default function App(){return <BrowserRouter><Layout/></BrowserRouter>}
