import {useState} from "react";
import {useNavigate} from "react-router-dom";
import api from "../services/api";

function Login(){
 const navigate=useNavigate(),[isSignup,setIsSignup]=useState(false),[form,setForm]=useState({name:"",email:"",password:""}),[error,setError]=useState(""),[success,setSuccess]=useState(""),[loading,setLoading]=useState(false);
 const submit=async e=>{e.preventDefault();setError("");setSuccess("");
  if(isSignup&&!form.name.trim())return setError("Please enter your full name.");
  if(!/\S+@\S+\.\S+/.test(form.email)||form.password.length<6)return setError("Use a valid email and a password of at least 6 characters.");
  setLoading(true);try{const r=await api.post(isSignup?"/auth/signup":"/auth/login",form);localStorage.setItem("glowora-token",r.data.token);localStorage.setItem("glowora-current-user",JSON.stringify(r.data.user));setSuccess(isSignup?"Account created successfully!":"Login successful!");setTimeout(()=>navigate("/profile"),500);}catch(e){setError(e.response?.data?.message||"Something went wrong.");}finally{setLoading(false);}
 };
 return <main className="auth-page"><div className="auth-card"><div className="auth-header"><p className="section-label">GLOWORA BEAUTY</p><h1>{isSignup?"Create Account":"Welcome Back"}</h1><p>{isSignup?"Create your Glowora Beauty account.":"Login to manage your account and orders."}</p></div>
 <form className="auth-form" onSubmit={submit}>{isSignup&&<div className="form-group"><label>Full Name</label><input name="name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Enter your full name"/></div>}
 <div className="form-group"><label>Email Address</label><input type="email" name="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="Enter your email"/></div>
 <div className="form-group"><label>Password</label><input type="password" name="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} placeholder="Minimum 6 characters"/></div>
 {error&&<p className="auth-error">{error}</p>}{success&&<p className="auth-success">{success}</p>}<button className="auth-submit" disabled={loading}>{loading?"Please wait...":isSignup?"Create Account":"Login"}</button></form>
 <div className="auth-switch"><span>{isSignup?"Already have an account?":"Don't have an account?"}</span><button type="button" onClick={()=>{setIsSignup(!isSignup);setError("");}}>{isSignup?"Login":"Create Account"}</button></div></div></main>
}
export default Login;
