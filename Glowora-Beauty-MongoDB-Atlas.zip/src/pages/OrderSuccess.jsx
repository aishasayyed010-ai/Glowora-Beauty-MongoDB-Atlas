import { Link } from "react-router-dom";

function OrderSuccess() {
  const order = JSON.parse(
    localStorage.getItem("glowora-orders")
  )?.[0];

  return (
    <main className="order-success-page">

      <div className="success-card">

        <div className="success-icon">
          ✓
        </div>

        <p className="section-label">
          GLOWORA BEAUTY
        </p>

        <h1>
          Order Placed Successfully!
        </h1>

        <p className="success-message">
          Thank you for shopping with Glowora Beauty.
          Your order has been successfully placed.
        </p>

        {order && (
          <div className="success-order-info">

            <div>
              <span>Order ID</span>
              <strong>
                #{order.id}
              </strong>
            </div>

            <div>
              <span>Total Amount</span>
              <strong>
                ₹{order.total.toLocaleString(
                  "en-IN",
                  {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2,
                  }
                )}
              </strong>
            </div>

            <div>
              <span>Status</span>
              <strong>
                {order.status}
              </strong>
            </div>

          </div>
        )}

        <div className="success-actions">

          <Link
            to="/profile"
            className="view-orders-btn"
          >
            View My Orders
          </Link>

          <Link
            to="/products"
            className="continue-shopping-btn"
          >
            Continue Shopping
          </Link>

        </div>

      </div>

    </main>
  );
}

export default OrderSuccess;