import {useState} from "react";
import {useNavigate} from "react-router-dom";
import {useCart} from "../context/CartContext";
import api from "../services/api";

function Checkout(){
 const navigate=useNavigate(),{cartItems,subtotal,shipping,gst,total,clearCart}=useCart();
 const [form,setForm]=useState({name:"",phone:"",address:"",pincode:"",location:"",landmark:""}),[error,setError]=useState(""),[loading,setLoading]=useState(false);
 const submit=async e=>{e.preventDefault();setError("");
  if(!form.name.trim()||!form.phone.trim()||!form.address.trim()||!form.pincode.trim())return setError("Please fill in all required fields.");
  if(!/^[6-9]\d{9}$/.test(form.phone))return setError("Please enter a valid 10-digit phone number.");
  if(!/^\d{6}$/.test(form.pincode))return setError("Please enter a valid 6-digit pincode.");
  if(!cartItems.length)return setError("Your cart is empty.");
  if(!localStorage.getItem("glowora-token"))return navigate("/login");
  setLoading(true);try{const r=await api.post("/orders",{customer:form,items:cartItems.map(i=>({productId:i._id||i.id,quantity:i.quantity}))});localStorage.setItem("glowora-last-order",JSON.stringify(r.data.order));clearCart();navigate("/order-success");}catch(e){setError(e.response?.data?.message||"Unable to place order.");}finally{setLoading(false);}
 };
 return <main className="checkout-page"><div className="checkout-header"><p className="section-label">GLOWORA CHECKOUT</p><h1>Complete Your Order</h1><p>Enter your delivery information below.</p></div>
 <div className="checkout-layout"><form className="checkout-form" onSubmit={submit}><h2>Delivery Information</h2>
 {["name","phone","address","pincode","location","landmark"].map(k=><div className="form-group" key={k}><label>{k[0].toUpperCase()+k.slice(1)} {["name","phone","address","pincode"].includes(k)?"*":""}</label>{k==="address"?<textarea name={k} value={form[k]} onChange={e=>setForm({...form,[k]:e.target.value})} rows="4"/>:<input name={k} value={form[k]} onChange={e=>setForm({...form,[k]:e.target.value})} maxLength={k==="phone"||k==="pincode"?10:undefined}/>}</div>)}
 {error&&<p className="checkout-error">{error}</p>}<button className="place-order-btn" disabled={loading}>{loading?"Placing Order...":"Place Order"}</button></form>
 <div className="checkout-summary"><h2>Order Summary</h2>{cartItems.map(i=><div className="checkout-product" key={i.id}><img src={i.image} alt={i.name}/><div><h4>{i.name}</h4><p>Qty: {i.quantity}</p></div><strong>₹{(i.price*i.quantity).toLocaleString("en-IN")}</strong></div>)}<div className="summary-divider"/><div className="summary-row"><span>Subtotal</span><span>₹{subtotal.toLocaleString("en-IN")}</span></div><div className="summary-row"><span>Shipping</span><span>{shipping===0?"FREE":`₹${shipping}`}</span></div><div className="summary-row"><span>GST (5%)</span><span>₹{gst.toFixed(2)}</span></div><div className="summary-divider"/><div className="summary-total"><span>Total</span><strong>₹{total.toFixed(2)}</strong></div></div></div></main>;
}
export default Checkout;
