import {useEffect,useState} from "react";
import {Link,useNavigate,useParams} from "react-router-dom";
import {FiShoppingBag} from "react-icons/fi";
import {useCart} from "../context/CartContext";
import api from "../services/api";

export default function ProductDetails(){
 const {id}=useParams(),navigate=useNavigate(),{addToCart}=useCart();const [product,setProduct]=useState(null);
 useEffect(()=>{api.get("/products").then(r=>setProduct(r.data.find(p=>String(p._id)===String(id))||null)).catch(()=>{});},[id]);
 if(!product)return <main className="product-not-found"><h1>Product Not Found</h1><Link to="/products">Back to Products</Link></main>;
 const cartProduct={...product,id:product._id};
 return <main className="product-details-page"><div className="product-details-container"><Link to="/products" className="back-products">← Back to Products</Link><div className="product-details-layout"><div className="product-details-image"><img src={product.image} alt={product.name}/></div><div className="product-details-info"><p className="details-category">{product.category}</p><h1>{product.name}</h1><div className="details-price">₹{product.price.toLocaleString("en-IN")}</div><div className="details-divider"/><p className="details-description">A carefully selected beauty product designed to enhance your everyday beauty routine.</p><div className="product-information"><h2>Product Information</h2><div className="information-item"><span>Category</span><strong>{product.category}</strong></div><div className="information-item"><span>Stock</span><strong>{product.stock} available</strong></div></div><div className="product-benefits"><h2>Benefits</h2><ul><li>✦ Easy to use</li><li>✦ Designed for everyday beauty routines</li><li>✦ Premium quality product</li><li>✦ Perfect for daily use</li></ul></div><div className="product-actions"><button className="details-add-cart" onClick={()=>addToCart(cartProduct)}><FiShoppingBag/> Add to Cart</button><button className="details-buy-now" onClick={()=>{addToCart(cartProduct);navigate("/cart")}}>Buy Now</button></div></div></div></div></main>;
}
