import { Link } from "react-router-dom";
import {
  FiMinus,
  FiPlus,
  FiTrash2,
} from "react-icons/fi";

import { useCart } from "../context/CartContext";

function Cart() {
  const {
    cartItems,
    increaseQuantity,
    decreaseQuantity,
    removeFromCart,
    subtotal,
    shipping,
    gst,
    gstRate,
    total,
  } = useCart();

  if (cartItems.length === 0) {
    return (
      <main className="cart-page empty-cart">

        <h1>Your Cart</h1>

        <p>
          Your shopping cart is currently empty.
        </p>

        <Link
          to="/products"
          className="continue-shopping"
        >
          Continue Shopping
        </Link>

      </main>
    );
  }

  return (
    <main className="cart-page">

      <div className="cart-header">
        <p className="section-label">
          YOUR BAG
        </p>

        <h1>Shopping Cart</h1>
      </div>

      <div className="cart-layout">

        {/* CART PRODUCTS */}

        <div className="cart-items">

          {cartItems.map((item) => (
            <div
              className="cart-item"
              key={item.id}
            >

              <img
                src={item.image}
                alt={item.name}
              />

              <div className="cart-item-info">

                <p className="product-category">
                  {item.category}
                </p>

                <h3>{item.name}</h3>

                <p className="cart-price">
                  ₹{item.price.toLocaleString("en-IN")}
                </p>

                <div className="quantity-controls">

                  <button
                    onClick={() =>
                      decreaseQuantity(item.id)
                    }
                  >
                    <FiMinus />
                  </button>

                  <span>
                    {item.quantity}
                  </span>

                  <button
                    onClick={() =>
                      increaseQuantity(item.id)
                    }
                  >
                    <FiPlus />
                  </button>

                </div>

              </div>

              <div className="cart-item-right">

                <strong>
                  ₹{(
                    item.price * item.quantity
                  ).toLocaleString("en-IN")}
                </strong>

                <button
                  className="remove-btn"
                  onClick={() =>
                    removeFromCart(item.id)
                  }
                >
                  <FiTrash2 />
                </button>

              </div>

            </div>
          ))}

        </div>

        {/* ORDER SUMMARY */}

        <div className="cart-summary">

          <h2>Order Summary</h2>

          {/* SUBTOTAL */}

          <div className="summary-row">
            <span>Subtotal</span>

            <span>
              ₹{subtotal.toLocaleString("en-IN")}
            </span>
          </div>

          {/* SHIPPING */}

          <div className="summary-row">
            <span>Shipping</span>

            <span>
              {shipping === 0
                ? "FREE"
                : `₹${shipping.toLocaleString("en-IN")}`}
            </span>
          </div>

          {/* FREE SHIPPING MESSAGE */}

          {subtotal < 999 && (
            <p className="shipping-message">
              Add ₹
              {(999 - subtotal).toLocaleString("en-IN")}
              {" "}more to get FREE shipping!
            </p>
          )}

          {subtotal >= 999 && (
            <p className="shipping-free">
              🎉 You qualify for FREE shipping!
            </p>
          )}

          {/* GST */}

          <div className="summary-row">
            <span>
              GST ({gstRate * 100}%)
            </span>

            <span>
              ₹{gst.toLocaleString("en-IN", {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
              })}
            </span>
          </div>

          {/* DIVIDER */}

          <div className="summary-divider" />

          {/* TOTAL */}

          <div className="summary-total">

            <span>Total</span>

            <strong>
              ₹{total.toLocaleString("en-IN", {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
              })}
            </strong>

          </div>

          {/* CHECKOUT */}

          <Link
            to="/checkout"
            className="checkout-btn"
          >
            Proceed to Checkout
          </Link>

        </div>

      </div>

    </main>
  );
}

export default Cart;