function Contact() {
  return (
    <main className="page">

      <h1>Contact Us</h1>

      <p>
        Have a question? We'd love to hear from you.
      </p>

      <p>
        Email: support@gloworabeauty.com
      </p>

    </main>
  );
}

export default Contact;