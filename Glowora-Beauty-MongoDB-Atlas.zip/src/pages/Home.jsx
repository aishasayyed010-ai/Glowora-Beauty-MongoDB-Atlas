function Home() {
  return (
    <main>

      <section className="hero">

        <div className="hero-content">

          <p className="hero-small">
            BEAUTY MADE SIMPLE
          </p>

          <h1>
            Your Everyday
            <br />
            Glow Starts Here
          </h1>

          <p>
            Discover skincare, makeup and beauty essentials
            selected for your everyday routine.
          </p>

          <button>
            Shop Now
          </button>

        </div>

      </section>

      <section className="categories">

        <h2>Shop By Category</h2>

        <div className="category-grid">

          <div className="category-card">
            <h3>Skincare</h3>
          </div>

          <div className="category-card">
            <h3>Makeup</h3>
          </div>

          <div className="category-card">
            <h3>Haircare</h3>
          </div>

          <div className="category-card">
            <h3>Body Care</h3>
          </div>

        </div>

      </section>

    </main>
  );
}

export default Home;