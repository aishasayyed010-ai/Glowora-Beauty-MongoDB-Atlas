import { useEffect, useState } from "react";
import ProductCard from "../components/ProductCard";
import { useCart } from "../context/CartContext";
import api from "../services/api";

function Products() {
  const [search,setSearch]=useState("");
  const [products,setProducts]=useState([]);
  const [message,setMessage]=useState("");
  const [loading,setLoading]=useState(true);
  const {addToCart}=useCart();

  useEffect(()=>{api.get("/products").then(r=>setProducts(r.data)).catch(()=>{}).finally(()=>setLoading(false));},[]);
  const filtered=products.filter(p=>p.name.toLowerCase().includes(search.toLowerCase()));
  const handleAdd=(p)=>{addToCart({...p,id:p._id});setMessage(`${p.name} added to cart!`);setTimeout(()=>setMessage(""),2000);};

  return <main className="products-page">
    {message&&<div className="cart-toast"><span>✓</span><div><strong>Product Added!</strong><p>{message}</p></div></div>}
    <div className="products-header"><div><p className="section-label">GLOWORA COLLECTION</p><h1>All Beauty Products</h1><p>Find your skincare, makeup and beauty essentials.</p></div>
      <input type="text" placeholder="Search products..." value={search} onChange={e=>setSearch(e.target.value)} className="product-search"/>
    </div>
    {loading?<p>Loading products...</p>:<div className="product-grid">{filtered.map(p=><ProductCard key={p._id} product={{...p,id:p._id}} onAddToCart={handleAdd}/>)}</div>}
    {!loading&&!filtered.length&&<div className="no-products"><h2>No products found</h2><p>Try another search.</p></div>}
  </main>;
}
export default Products;
