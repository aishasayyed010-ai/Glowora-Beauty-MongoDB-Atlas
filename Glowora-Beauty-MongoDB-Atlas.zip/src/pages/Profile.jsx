import {useEffect,useState} from "react";
import {Link,useNavigate} from "react-router-dom";
import api from "../services/api";

function Profile(){
 const navigate=useNavigate(),[user,setUser]=useState(null),[orders,setOrders]=useState([]);
 useEffect(()=>{if(!localStorage.getItem("glowora-token"))return navigate("/login");Promise.all([api.get("/auth/me"),api.get("/orders/my")]).then(([u,o])=>{setUser(u.data.user);setOrders(o.data);}).catch(()=>{localStorage.clear();navigate("/login");});},[navigate]);
 const logout=()=>{localStorage.removeItem("glowora-token");localStorage.removeItem("glowora-current-user");navigate("/login");};
 if(!user)return <main className="profile-page"><p>Loading account...</p></main>;
 return <main className="profile-page"><div className="profile-header"><div><p className="section-label">GLOWORA BEAUTY</p><h1>My Account</h1><p>Manage your account and view your orders.</p></div><button className="logout-btn" onClick={logout}>Logout</button></div>
 <div className="profile-layout"><section className="profile-card"><div className="profile-card-header"><div><p className="profile-label">ACCOUNT</p><h2>Account Details</h2></div><div className="profile-avatar">{user.name?.charAt(0).toUpperCase()}</div></div><div className="account-section"><h3>Personal Information</h3><div className="account-grid"><div className="account-field"><span>Full Name</span><strong>{user.name}</strong></div><div className="account-field"><span>Email Address</span><strong>{user.email}</strong></div></div></div></section>
 <section className="orders-card"><div className="orders-header"><div><p className="profile-label">PURCHASE HISTORY</p><h2>My Orders</h2></div><span className="order-count">{orders.length} Orders</span></div>{orders.length===0?<div className="no-orders"><h3>No orders yet</h3><p>Your placed orders will appear here.</p><Link to="/products" className="shop-now-btn">Shop Now</Link></div>:<div className="orders-list">{orders.map(o=><div className="order-card" key={o._id}><div className="order-top"><div><span>Order ID</span><strong>#{o.orderNumber}</strong></div><span className="order-status">{o.status}</span></div><div className="order-date">{new Date(o.createdAt).toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"})}</div><div className="order-products">{o.items.slice(0,3).map(i=><div className="order-product" key={i.productId}><img src={i.image} alt={i.name}/><div><strong>{i.name}</strong><span>Qty: {i.quantity}</span></div></div>)}</div><div className="summary-total"><span>Total</span><strong>₹{o.pricing.total.toFixed(2)}</strong></div></div>)}</div>}</section></div></main>;
}
export default Profile;
