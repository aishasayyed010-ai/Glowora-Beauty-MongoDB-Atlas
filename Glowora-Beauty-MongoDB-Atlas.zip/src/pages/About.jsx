import { Link } from "react-router-dom";

function About() {
  return (
    <main className="about-page">

      {/* HERO */}

      <section className="about-hero">

        <p className="section-label">
          ABOUT GLOWORA
        </p>

        <h1>
          Beauty Made Simple.
        </h1>

        <p>
          Discover beauty products carefully selected
          to make your everyday routine feel special.
        </p>

      </section>


      {/* OUR STORY */}

      <section className="about-section">

        <div className="about-content">

          <p className="section-label">
            OUR STORY
          </p>

          <h2>
            Beauty that feels good.
          </h2>

          <p>
            Glowora Beauty was created with a simple idea:
            finding quality beauty products should be easy,
            enjoyable, and accessible.
          </p>

          <p>
            From skincare to makeup and everyday beauty
            essentials, we bring everything together in
            one beautiful shopping experience.
          </p>

        </div>

      </section>


      {/* WHY CHOOSE US */}

      <section className="about-features">

        <p className="section-label">
          WHY GLOWORA
        </p>

        <h2>
          Why shop with us?
        </h2>

        <div className="features-grid">

          <div className="feature-card">

            <div className="feature-icon">
              ✨
            </div>

            <h3>
              Quality Products
            </h3>

            <p>
              Carefully selected beauty products
              for your everyday routine.
            </p>

          </div>


          <div className="feature-card">

            <div className="feature-icon">
              💗
            </div>

            <h3>
              Customer First
            </h3>

            <p>
              We want every shopping experience
              to feel simple and enjoyable.
            </p>

          </div>


          <div className="feature-card">

            <div className="feature-icon">
              🚚
            </div>

            <h3>
              Easy Delivery
            </h3>

            <p>
              Convenient delivery with free shipping
              on orders of ₹999 or more.
            </p>

          </div>

        </div>

      </section>


      {/* MISSION */}

      <section className="about-mission">

        <p className="section-label">
          OUR MISSION
        </p>

        <h2>
          Your beauty. Your choice.
        </h2>

        <p>
          Our goal is to create a trusted online beauty
          destination where customers can discover,
          compare, and purchase products with confidence.
        </p>

        <Link
          to="/products"
          className="about-shop-btn"
        >
          Explore Products
        </Link>

      </section>

    </main>
  );
}

export default About;