const products = [
  {
    id: 1,
    name: "Rose Glow Face Serum",
    category: "Skincare",
    price: 599,
    image:
      "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=600&q=80",
  },

  {
    id: 2,
    name: "Hydra Dew Moisturizer",
    category: "Skincare",
    price: 449,
    image:
      "https://images.unsplash.com/photo-1556229010-6c3f2c9ca5f8?auto=format&fit=crop&w=600&q=80",
  },

  {
    id: 3,
    name: "Velvet Matte Lipstick",
    category: "Makeup",
    price: 399,
    image:
      "https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&w=600&q=80",
  },

  {
    id: 4,
    name: "Soft Focus Foundation",
    category: "Makeup",
    price: 799,
    image:
      "https://images.unsplash.com/photo-1631730486572-226d1f595b68?auto=format&fit=crop&w=600&q=80",
  },

  {
    id: 5,
    name: "Peach Glow Blush",
    category: "Makeup",
    price: 349,
    image:
      "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=600&q=80",
  },

  {
    id: 6,
    name: "Silky Hair Repair Mask",
    category: "Haircare",
    price: 549,
    image:
      "https://images.unsplash.com/photo-1522338242992-e1a54906a8da?auto=format&fit=crop&w=600&q=80",
  },

  {
    id: 7,
    name: "Everyday SPF 50",
    category: "Skincare",
    price: 499,
    image:
      "https://images.unsplash.com/photo-1556228578-8c89e6adf883?auto=format&fit=crop&w=600&q=80",
  },

  {
    id: 8,
    name: "Vanilla Cloud Body Mist",
    category: "Body Care",
    price: 699,
    image:
      "https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&w=600&q=80",
  },
];

export default products;